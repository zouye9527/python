"""
小王编写了一个程序revise.py，根据键盘上输入的姓名和分数，做出相应的输出。
代码有错误，请帮助修改。
输入样例：
Mike
56
输出样例：
Mike分数为 56
"""
name=input()
score=eval(input())
print(name,end="")
print("分数为"+score)

