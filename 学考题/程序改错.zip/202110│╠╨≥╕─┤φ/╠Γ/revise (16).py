"""
小明编写了一个程序revise.py，从键盘上输入一个正整数，
判断它是奇数还是偶数。代码中存在错误，请帮助修改。
"""
a=eval(input())
if a/2=a//2:
    print("偶数")
else:
    print("奇数")
