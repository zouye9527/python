"""
王老师在上课时编写了一个程序revise.py，用于讲解Python中的数据类型，
代码中存在错误，请帮助修改。
"""
b=input()
c="Hello,world"
print(type(b),type(c))
