"""
小王编写了一个程序revise.py，从键盘上输入两个数，输出两个数之和。
代码有错误，请帮助修改。
"""
def add(a,b):
    c=a+b
    return c
x=eval(input())
y=eval(input())
z=add(x,y)
print(z)


