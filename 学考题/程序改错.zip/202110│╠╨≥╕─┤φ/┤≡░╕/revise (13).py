"""
小明编写了一个程序revise.py，根据键盘上输入的n值，输出1到n（含）之间的正整数的奇偶情况。
代码中存在错误，请帮助修改。
输入样例：
5
输出样例：
1 is odd
2 is even
3 is odd
4 is even
5 is odd
"""
n=eval(input())
a=1
while a<n+1:
    if a%2==0:
        print(a,"is even")
    else:
        print(a,"is odd")
    a=a+1
