"""
王老师在课上编写了一个程序revise.py，根据键盘输入的姓名、性别、班级，
输出相关信息。代码中存在错误，请帮助修改。
输入样例：
Alice
female
1班
输出样例：
Alice female 1班
"""
name=input()
gender=input()
class0=input()

print(name,gender,class0)
