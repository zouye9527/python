n=int(input())
if n<0:
    print("Negative")  #Python语言标识语句之间的层次关系
elif n==0:
    print("Zero")
else:
    print("Positive")
