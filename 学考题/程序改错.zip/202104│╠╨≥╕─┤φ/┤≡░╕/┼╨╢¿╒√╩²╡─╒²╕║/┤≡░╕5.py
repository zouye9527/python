n=int(input())
if n<0:
    print("Negative")
if n>0:
    print("Positive")
if n==0:
    print("Zero")
