n=int(input())
if n<0:
    print("Negative")
elif n==0:  #Python语言中==的书写
    print("Zero")
else:
    print("Positive")
