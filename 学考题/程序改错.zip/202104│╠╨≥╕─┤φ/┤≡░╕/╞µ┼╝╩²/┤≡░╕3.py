n=eval(input())
if n%2==0:
    print("odd")#缺引号
if n%2==1:
    print("even")
