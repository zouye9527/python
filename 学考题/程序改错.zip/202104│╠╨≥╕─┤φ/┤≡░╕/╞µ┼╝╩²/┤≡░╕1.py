n=eval(input())
if n%2==0:
    print("even")
else:
    print("odd")
