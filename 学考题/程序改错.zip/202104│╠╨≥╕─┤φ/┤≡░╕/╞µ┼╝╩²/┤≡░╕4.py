n=eval(input())
if n%2==0:#取模%
    print("even")
if n%2==1:
    print("odd")
