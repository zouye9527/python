n=eval(input())
if n%2==1:
    print("odd")
if n%2==0:
    print("even")
