n=eval(input())
if n%2==0:
    print("even")
if n%2==1:
    print("odd")
