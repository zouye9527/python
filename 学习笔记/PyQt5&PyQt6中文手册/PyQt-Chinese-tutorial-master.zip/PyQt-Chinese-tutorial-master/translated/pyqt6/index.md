# Python PyQt6
*最后更新于 2021.05.18*

这是一个 PyQt6 教程。本教程是个初、中级教程，学完本教程后，您可以编写一个非常不错的 PyQt6 应用。代码示例在作者的 Github 仓库 [PyQt6-Tutorial-Examples](https://github.com/janbodnar/PyQt6-Tutorial-Examples)。


一本涵盖 PyQt5 库的高级特性的电子书: [Advanced PyQt5 e-book](https://zetcode.com/ebooks/advancedpyqt5/).

## 相关教程

[PyQt5 tutorial](https://zetcode.com/gui/pyqt5/) 是介绍了上个版本的 PyQt 。

 [wxPython tutorial](https://zetcode.com/wxpython/) 、 [Python Gtk tutorial](https://zetcode.com/python/gtk/) 和
 [Tkinter tutorial](https://zetcode.com/tkinter/) 是关于其他比较流行的 Python GUI 教程。